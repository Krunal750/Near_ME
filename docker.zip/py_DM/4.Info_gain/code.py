import csv
import math

# Function to calculate entropy
def calculate_entropy(pos, neg):
    total = pos + neg
    if total == 0:
        return 0
    prob_pos = pos / total
    prob_neg = neg / total
    entropy = 0
    if prob_pos > 0:
        entropy -= prob_pos * math.log2(prob_pos)
    if prob_neg > 0:
        entropy -= prob_neg * math.log2(prob_neg)
    return entropy

# Read data from CSV file
filename = "exp3_input.csv"
output_filename = "output.txt"

try:
    with open(filename, 'r') as file, open(output_filename, 'w') as output_file:
        reader = csv.reader(file)
        header = next(reader)  # Skip the header row
        print("Enter Child Column Number (1 for day, 2 for level, 3 for Routine, 4 for value): ")
        choice = int(input("Enter Child Column Number: "))
        output_file.write(f"Enter Child Column Number: {choice}\n")
        
        # Map to store counts
        parent = {"Yes": 0, "No": 0}
        child = {}

        # Iterate over rows in CSV
        for row in reader:
            day, level, routine, play_game, value = row
            
            # Determine child name based on choice
            if choice == 1:
                child_name = day
            elif choice == 2:
                child_name = level
            elif choice == 3:
                child_name = routine
            elif choice == 4:
                child_name = value
            else:
                child_name = routine  # Default case

            # Increment counts
            parent[play_game] = parent.get(play_game, 0) + 1
            if child_name not in child:
                child[child_name] = {"Yes": 0, "No": 0}
            child[child_name][play_game] += 1

        # Calculate parent entropy
        pos = parent.get("Yes", 0)
        neg = parent.get("No", 0)
        total = pos + neg
        parent_entropy = calculate_entropy(pos, neg)
        output_file.write(f"Parent Entropy: {parent_entropy}\n")

        # Calculate weighted child entropy
        child_entropy = 0
        for child_name, counts in child.items():
            pR = counts.get("Yes", 0)
            nR = counts.get("No", 0)
            tR = pR + nR
            proportion = tR / total
            child_entropy += proportion * calculate_entropy(pR, nR)

        output_file.write(f"Child Entropy * Their proportion: {child_entropy}\n")
        
        # Calculate information gain
        info_gain = parent_entropy - child_entropy
        output_file.write(f"Info gain: {info_gain}\n")
        print(f"Binning results have been saved to {output_filename}")

except FileNotFoundError:
    print(f"Error: Could not open the file {filename}.")
