import csv
from collections import defaultdict
from itertools import combinations

# Function to split a string into words based on alphanumeric characters
def wordsof(string):
    words = []
    word = ''
    for char in string:
        if char.isalnum():
            word += char
        else:
            if word:
                words.append(word)
                word = ''
    if word:
        words.append(word)
    return words

# Function to combine elements of a list into a single string, omitting the element at index 'miss'
def combine(arr, miss):
    return ' '.join(arr[i] for i in range(len(arr)) if i != miss)

# Function to create a new set identical to the given set
def cloneit(arr):
    return set(arr)

# Apriori generation function for k-itemsets
def apriori_gen(sets, k):
    new_set = set()
    sets = list(sets)
    for i in range(len(sets)):
        for j in range(i + 1, len(sets)):
            v1, v2 = wordsof(sets[i]), wordsof(sets[j])
            if v1[:k - 1] == v2[:k - 1]:
                merged = sorted(set(v1) | set(v2))
                candidate = combine(merged, -1)
                if all(combine(merged, miss) in sets for miss in range(len(merged))):
                    new_set.add(candidate)
    return new_set

# Load transactions and calculate frequency of single items
file_path = "exp6_input.csv"
minfre = float(input("Frequency % : "))
datatable = []
products = set()
freq = defaultdict(int)

with open(file_path, newline='') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        row_set = set(wordsof(" ".join(row)))
        datatable.append(row_set)
        for product in row_set:
            products.add(product)
            freq[product] += 1

# Calculate minimum frequency threshold
num_transactions = len(datatable)
min_count = minfre * num_transactions / 100

# Filter out infrequent single items
products = {p for p in products if freq[p] >= min_count}

# Print frequent 1-itemsets
print(f"No of transactions: {num_transactions}")
print(f"Min frequency: {min_count}")
print(f"\nFrequent 1-item set:")
for product in products:
    print(f"{{{product}}} {freq[product]}")

# Iteratively generate frequent k-itemsets
prev_set = cloneit(products)
k = 2
pass_num = 2
while prev_set:
    cur_set = apriori_gen(prev_set, k - 1)
    if not cur_set:
        break

    # Count occurrences for each candidate k-itemset
    cur_freq = defaultdict(int)
    for candidate in cur_set:
        candidate_words = wordsof(candidate)
        count = sum(all(word in transaction for word in candidate_words) for transaction in datatable)
        if count >= min_count:
            cur_freq[candidate] = count

    # Filter current set by minimum frequency
    cur_set = {item for item in cur_set if cur_freq[item] >= min_count}
    if not cur_set:
        break

    # Print frequent k-itemsets
    print(f"\n\nFrequent {pass_num} -item set:")
    for item in cur_set:
        print(f"{{{item}}} {cur_freq[item]}")

    prev_set = cloneit(cur_set)
    k += 1
    pass_num += 1

# Save frequent itemsets to output file
with open("freqitem_op.csv", "w", newline='') as fw:
    writer = csv.writer(fw)
    for item in prev_set:
        writer.writerow([f"{{{item}}}"])
