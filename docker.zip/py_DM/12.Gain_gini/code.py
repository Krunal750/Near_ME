import math
import csv

# Function to calculate entropy
def calculate_entropy(yes, no):
    total = yes + no
    if total == 0:
        return 0  # To avoid division by zero
    p_yes = yes / total
    p_no = no / total

    entropy = 0
    if p_yes > 0:
        entropy -= p_yes * math.log2(p_yes)
    if p_no > 0:
        entropy -= p_no * math.log2(p_no)

    return entropy

# Function to calculate Gini Index
def calculate_gini(yes, no):
    total = yes + no
    if total == 0:
        return 0  # To avoid division by zero
    p_yes = yes / total
    p_no = no / total

    gini = 1 - (p_yes * p_yes + p_no * p_no)
    return gini

# Function to read CSV file and parse the data
def read_csv(filename):
    data = []
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)
    return data

# Function to write result to CSV file
def write_csv(filename, log_data):
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        for line in log_data:
            writer.writerow([line])

# Function to check if a string is numeric
def is_numeric(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

# Function to split and calculate for numerical data
def calculate_for_numerical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples):
    unique_values = set(float(row[feature_col]) for row in data[1:])
    
    best_info_gain = -1
    best_split = None
    best_final_gini = 0

    for split_point in unique_values:
        left_yes = left_no = right_yes = right_no = 0

        for i in range(1, len(data)):
            feature_value = float(data[i][feature_col])
            target_value = data[i][target_col]

            if feature_value <= split_point:
                if target_value == 'Yes':
                    left_yes += 1
                else:
                    left_no += 1
            else:
                if target_value == 'Yes':
                    right_yes += 1
                else:
                    right_no += 1

        left_total = left_yes + left_no
        right_total = right_yes + right_no
        weighted_entropy = ((left_total / total_samples) * calculate_entropy(left_yes, left_no)) + \
                           ((right_total / total_samples) * calculate_entropy(right_yes, right_no))
        weighted_gini = ((left_total / total_samples) * calculate_gini(left_yes, left_no)) + \
                        ((right_total / total_samples) * calculate_gini(right_yes, right_no))

        info_gain = parent_entropy - weighted_entropy

        log_entry = f"Split Point: {split_point}, Weighted Entropy: {weighted_entropy}, Gini Index: {weighted_gini}, Information Gain: {info_gain}"
        log_data.append(log_entry)

        if info_gain > best_info_gain:
            best_info_gain = info_gain
            best_split = split_point
            best_final_gini = weighted_gini

    log_data.append(f"Best Split Point: {best_split} with Information Gain: {best_info_gain}")
    return best_final_gini

# Function to split and calculate for categorical data
def calculate_for_categorical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples):
    feature_map = {}

    for i in range(1, len(data)):
        feature_value = data[i][feature_col]
        target_value = data[i][target_col]

        if feature_value not in feature_map:
            feature_map[feature_value] = {}
        if target_value not in feature_map[feature_value]:
            feature_map[feature_value][target_value] = 0
        feature_map[feature_value][target_value] += 1

    weighted_entropy = 0
    weighted_gini_index = 0
    for feature_value, target_map in feature_map.items():
        feature_total = sum(target_map.values())
        feature_entropy = 0
        feature_gini = 0

        for target_value, count in target_map.items():
            p = count / feature_total
            if p > 0:
                feature_entropy -= p * math.log2(p)

            feature_gini += p * p

        feature_gini = 1 - feature_gini

        weighted_entropy += (feature_total / total_samples) * feature_entropy
        weighted_gini_index += (feature_total / total_samples) * feature_gini

        log_data.append(f"Feature: {feature_value} | Weighted Entropy: {feature_entropy} | Gini Index: {feature_gini}")

    info_gain = parent_entropy - weighted_entropy
    log_data.append(f"Information Gain for Selected Feature: {info_gain}")
    return weighted_gini_index

def main():
    input_file = 'input.csv'
    data = read_csv(input_file)

    target_col = int(input("Enter the index of the target column (0-indexed): "))
    feature_col = int(input("Enter the index of the feature column (0-indexed): "))

    if len(data) < 2 or target_col >= len(data[0]) or feature_col >= len(data[0]):
        print("Invalid input or no data found in the CSV file.")
        return

    target_count = {}
    total_samples = len(data) - 1

    for i in range(1, len(data)):
        target_value = data[i][target_col]
        if target_value not in target_count:
            target_count[target_value] = 0
        target_count[target_value] += 1

    parent_entropy = 0
    for count in target_count.values():
        p = count / total_samples
        if p > 0:
            parent_entropy -= p * math.log2(p)

    log_data = [f"Parent Entropy: {parent_entropy}"]

    best_final_gini = 0
    if is_numeric(data[1][feature_col]):
        log_data.append("Numerical Feature Selected")
        best_final_gini = calculate_for_numerical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples)
    else:
        log_data.append("Categorical Feature Selected")
        best_final_gini = calculate_for_categorical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples)

    log_data.append(f"Final Gini Index after Best Split: {best_final_gini}")

    output_file = 'output.csv'
    write_csv(output_file, log_data)

    print(f"Results written to {output_file}")

if __name__ == "__main__":
    main()
