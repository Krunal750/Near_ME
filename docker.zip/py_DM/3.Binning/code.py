import csv

# Function to read data from a CSV file
def read_data_from_csv(filename):
    data = []
    try:
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                # Assuming the CSV contains one column of numerical data
                for cell in row:
                    try:
                        value = float(cell)  # Convert string to float
                        data.append(value)
                    except ValueError:
                        print(f"Invalid data encountered: {cell}")
    except FileNotFoundError:
        print(f"Could not open the file: {filename}")
    return data

# Function to perform binning and output results to a file
def perform_binning(data, num_bins, output_filename):
    if not data:
        print("No data available to perform binning.")
        return

    # Find the minimum and maximum values in the data
    min_val = min(data)
    max_val = max(data)

    # Calculate the bin width
    bin_width = (max_val - min_val) / num_bins

    # Create bins: a list of lists to store the data points in each bin
    bins = [[] for _ in range(num_bins)]

    # Assign data points to bins
    for value in data:
        bin_index = min(int((value - min_val) / bin_width), num_bins - 1)
        bins[bin_index].append(value)

    # Output the binning result to both the console and the output file
    with open(output_filename, 'w') as output_file:
        print("Binning results:")
        output_file.write("Binning results:\n")
        for i in range(num_bins):
            bin_start = min_val + i * bin_width
            bin_end = bin_start + bin_width
            print(f"Bin {i + 1} ({bin_start} to {bin_end}): {len(bins[i])} items")
            output_file.write(f"Bin {i + 1} ({bin_start} to {bin_end}): {len(bins[i])} items\n")

            # Output the data points in each bin
            print("Data in this bin:", " ".join(map(str, bins[i])))
            output_file.write("Data in this bin: " + " ".join(map(str, bins[i])) + "\n")

    print(f"Binning results have been saved to {output_filename}")

def main():
    # File containing the CSV data (one column of numbers)
    filename = "data.csv"

    # Output file to store the results
    output_filename = "output.txt"

    # Read data from CSV file
    data = read_data_from_csv(filename)

    # Number of bins
    num_bins = 5

    # Perform binning and write the results to the output file
    perform_binning(data, num_bins, output_filename)

if __name__ == "__main__":
    main()
