def algomerative(input_file):
    global op  # Declare 'op' as a global variable
    
    # Read the input file into a dictionary
    dm = {}
    
    with open(input_file, "r") as file:
        reader = csv.reader(file)
        points = next(reader)[1:]  # Skip the first column (point names)
        
        # Initialize the dictionary for distances
        for row in reader:
            # Skip empty rows or rows with incorrect number of columns
            if len(row) < len(points) + 1:
                continue  # Skip this row
            
            point = row[0]
            distances = row[1:]

            # Filter out any empty or invalid distance values
            valid_distances = []
            for dist in distances:
                try:
                    valid_distances.append(int(dist.strip()) if dist.strip() else sys.maxsize)
                except ValueError:
                    valid_distances.append(sys.maxsize)
            dm[point] = dict(zip(points, valid_distances))

    # Find the minimum distance pair
    min_dist = sys.maxsize
    pt1, pt2 = None, None
    
    for p in dm:
        for pp in dm[p]:
            dist = dm[p][pp]
            if p != pp and dist < min_dist:
                pt1, pt2 = p, pp
                min_dist = dist
    
    print(f"Clusters Chosen: {pt1} {pt2}")

    # Determine which point comes first alphabetically
    if pt1 > pt2:
        up, down = pt2, pt1
    else:
        up, down = pt1, pt2

    # Combine the two clusters
    newPt = down + up

    # Initialize newPt in the dictionary if it does not exist
    if newPt not in dm:
        dm[newPt] = {}

    # Update the distances for the new combined cluster
    for p in list(dm.keys()):
        if p > newPt:
            dm[p][newPt] = min(dm[p][up], dm[p][down])

    for p in dm[down]:
        d1 = dm[down][p]
        if p < up:
            d1 = min(d1, dm[up][p])
        else:
            d1 = min(d1, dm[p][up])
        dm[newPt][p] = d1

    for p in list(dm.keys()):
        if p >= up:
            d1 = dm[p][up]
            if down > p:
                d1 = min(d1, dm[down][p])
            else:
                d1 = min(d1, dm[p][down])
            dm[p][newPt] = d1
            del dm[p][up]
            if p >= down:
                del dm[p][down]

    del dm[up]
    del dm[down]

    # Write the new matrix to a new file
    output_file = f"output{op}.csv"
    op += 1

    with open(output_file, "w") as fw:
        writer = csv.writer(fw)
        writer.writerow([""] + list(dm.keys()))
        for point, distances in dm.items():
            writer.writerow([point] + list(distances.values()))

    fwtr.write(f"{down} & {up}\n")

    return output_file
