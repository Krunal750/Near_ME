import pandas as pd
import itertools

# Helper function to convert the string to a list of words
def wordsof(s):
    return [word for word in s.split() if word.isalnum()]

# Function to calculate support for items
def count_occurrences(v, datatable):
    count = 0
    for transaction in datatable:
        if all(item in transaction for item in v):
            count += 1
    return count

# Function to generate association rules
def generate_association_rules(frequent_items, min_support, confidence, datatable):
    association_rules = []
    for itemset in frequent_items:
        items = wordsof(itemset)
        for i in range(1, len(items)):
            for subset in itertools.combinations(items, i):
                subset = set(subset)
                remaining = set(items) - subset
                count_subset = count_occurrences(subset, datatable)
                count_remaining = count_occurrences(remaining, datatable)
                
                if count_subset >= min_support:
                    conf = count_remaining / count_subset * 100
                    if conf >= confidence:
                        association_rules.append((subset, remaining, conf))
    return association_rules

def main():
    # Read the CSV file
    try:
        df = pd.read_csv("exp7_input.csv", header=None, on_bad_lines='skip')
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return
    
    # Get user input for support and confidence
    minfre = float(input("Enter Support %: "))
    confidence = float(input("Enter Confidence %: "))
    
    # Convert data into a list of sets representing transactions
    datatable = []
    products = set()
    freq = {}
    
    for index, row in df.iterrows():
        items = wordsof(" ".join(row.dropna().astype(str)))  # Join the row into a single string, remove NaNs
        datatable.append(set(items))
        for item in items:
            products.add(item)
            freq[item] = freq.get(item, 0) + 1
    
    num_transactions = len(datatable)
    min_support = minfre * num_transactions / 100
    print(f"No of transactions: {num_transactions}")
    print(f"Min frequency: {min_support}")
    
    # Filter out products below min support
    products = {item for item in products if freq.get(item, 0) >= min_support}
    
    # Generate frequent 1-itemsets
    frequent_items = []
    for item in products:
        if freq[item] >= min_support:
            frequent_items.append(item)
    
    # Print frequent 1-itemsets
    print("\nFrequent 1-itemset:")
    for item in frequent_items:
        print(f"{{ {item} }} - {freq[item]}")
    
    # Generate frequent itemsets using Apriori algorithm
    pass_count = 1
    prev_frequent_itemsets = set(frequent_items)
    
    while prev_frequent_itemsets:
        curr_frequent_itemsets = set()
        for itemset1 in prev_frequent_itemsets:
            for itemset2 in prev_frequent_itemsets:
                if itemset1 != itemset2:
                    combined = set(itemset1.split() + itemset2.split())
                    count = count_occurrences(combined, datatable)
                    if count >= min_support:
                        curr_frequent_itemsets.add(" ".join(sorted(combined)))
        
        if curr_frequent_itemsets:
            print(f"\nFrequent {pass_count + 1}-itemset:")
            for itemset in curr_frequent_itemsets:
                print(f"{{ {itemset} }}")
            
            prev_frequent_itemsets = curr_frequent_itemsets
            pass_count += 1
        else:
            break
    
    # Generate association rules
    print("\nAssociation Rules:")
    rules = generate_association_rules(prev_frequent_itemsets, min_support, confidence, datatable)
    
    # Output the association rules
    with open("exp7_output.csv", "w") as fw:
        for rule in rules:
            antecedent, consequent, conf = rule
            fw.write(f"{{ {' '.join(antecedent)} }} -> {{ {' '.join(consequent)} }} , {conf:.2f}%\n")
            print(f"{{ {' '.join(antecedent)} }} -> {{ {' '.join(consequent)} }} , {conf:.2f}%")

if __name__ == "__main__":
    main()
