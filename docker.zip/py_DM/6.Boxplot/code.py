import csv

class Summary:
    def __init__(self, min_val, Q1, median, Q3, max_val, IQR):
        self.min = min_val
        self.Q1 = Q1
        self.median = median
        self.Q3 = Q3
        self.max = max_val
        self.IQR = IQR

def read_csv(file_path):
    data = []
    with open(file_path, mode='r') as file:
        reader = csv.reader(file)
        for row in reader:
            data.append([float(value) for value in row])
    return data

def five_number_summary(column):
    sorted_col = sorted(column)
    n = len(sorted_col)
    
    min_val = sorted_col[0]
    max_val = sorted_col[-1]
    
    # Median
    median = (sorted_col[n // 2 - 1] + sorted_col[n // 2]) / 2.0 if n % 2 == 0 else sorted_col[n // 2]
    
    # Q1
    lower_half = sorted_col[:n // 2]
    Q1 = (lower_half[len(lower_half) // 2 - 1] + lower_half[len(lower_half) // 2]) / 2.0 if len(lower_half) % 2 == 0 else lower_half[len(lower_half) // 2]
    
    # Q3
    upper_half = sorted_col[(n + 1) // 2:]
    Q3 = (upper_half[len(upper_half) // 2 - 1] + upper_half[len(upper_half) // 2]) / 2.0 if len(upper_half) % 2 == 0 else upper_half[len(upper_half) // 2]
    
    IQR = Q3 - Q1
    return Summary(min_val, Q1, median, Q3, max_val, IQR)

def process_csv(input_file_path, output_file_path):
    data = read_csv(input_file_path)

    if not data:
        print("No data found!")
        return
    
    rows = len(data)
    columns = len(data[0])

    # Transpose the data to process each column
    transposed = [[data[i][j] for i in range(rows)] for j in range(columns)]

    # Write summaries to the output file
    with open(output_file_path, mode='w') as output_file:
        for i, column_data in enumerate(transposed):
            summary = five_number_summary(column_data)
            output_file.write(f"Summary for Column {i + 1}:\n")
            output_file.write(f"Min: {summary.min}\n")
            output_file.write(f"Q1: {summary.Q1}\n")
            output_file.write(f"Median: {summary.median}\n")
            output_file.write(f"Q3: {summary.Q3}\n")
            output_file.write(f"Max: {summary.max}\n")
            output_file.write(f"IQR: {summary.IQR}\n\n")

if __name__ == "__main__":
    input_file = "data.csv"     # Input CSV file path
    output_file = "summary.txt" # Output summary file path
    process_csv(input_file, output_file)
