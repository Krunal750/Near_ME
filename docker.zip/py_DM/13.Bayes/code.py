import math
import csv

# Function to calculate mean of a list of values
def calculate_mean(values):
    return sum(values) / len(values)

# Function to calculate standard deviation of a list of values
def calculate_std_dev(values, mean):
    return math.sqrt(sum([(x - mean) ** 2 for x in values]) / len(values))

# Gaussian Probability Density Function for numerical data
def calculate_gaussian_probability(x, mean, std_dev):
    return (1 / (math.sqrt(2 * math.pi) * std_dev)) * math.exp(-((x - mean) ** 2) / (2 * std_dev ** 2))

# Function to read CSV file and parse the data
def read_csv(filename):
    data = []
    try:
        with open(filename, mode='r') as file:
            csv_reader = csv.reader(file)
            for row in csv_reader:
                data.append(row)
    except FileNotFoundError:
        print(f"Error opening file: {filename}")
    return data

# Function to write output to CSV file
def write_csv(filename, log_data):
    try:
        with open(filename, mode='w', newline='') as file:
            csv_writer = csv.writer(file)
            for line in log_data:
                csv_writer.writerow([line])
    except Exception as e:
        print(f"Error opening file for writing: {filename}, {e}")

# Function to train Naive Bayes for categorical and numerical data
def train_naive_bayes(data, target_col):
    categorical_counts = {}
    numerical_stats = {}
    class_counts = {}

    for i in range(1, len(data)):  # Start from 1 to skip header
        target_class = data[i][target_col]
        if target_class not in class_counts:
            class_counts[target_class] = 0
        class_counts[target_class] += 1

        for j in range(len(data[0])):
            if j == target_col:
                continue  # Skip target column

            value = data[i][j]
            if value.replace('.', '', 1).isdigit():  # Check if it's numerical
                if target_class not in numerical_stats:
                    numerical_stats[target_class] = {}
                if j not in numerical_stats[target_class]:
                    numerical_stats[target_class][j] = []
                numerical_stats[target_class][j].append(float(value))
            else:  # Categorical data
                if target_class not in categorical_counts:
                    categorical_counts[target_class] = {}
                if j not in categorical_counts[target_class]:
                    categorical_counts[target_class][j] = {}
                if value not in categorical_counts[target_class][j]:
                    categorical_counts[target_class][j][value] = 0
                categorical_counts[target_class][j][value] += 1

    return categorical_counts, numerical_stats, class_counts

# Function to predict class for a new instance and log all probabilities to CSV
def predict_naive_bayes(data, target_col, categorical_counts, numerical_stats, class_counts, instance):
    total_samples = len(data) - 1  # Total number of samples (excluding header)
    best_prob = -1
    best_class = None

    log_data = ["Class,Prior Probability,Feature Probabilities,Total Probability"]

    for target_class, class_count in class_counts.items():
        class_prob = class_count / total_samples
        initial_class_prob = class_prob  # Save initial class probability for logging
        log_line = f"{target_class},{class_prob}"

        # Calculate probabilities for each feature
        for j in range(len(instance)):
            if j == target_col:
                continue  # Skip the target column

            value = instance[j]
            if value.replace('.', '', 1).isdigit():  # Numerical feature
                values = numerical_stats[target_class].get(j, [])
                mean = calculate_mean(values)
                std_dev = calculate_std_dev(values, mean)
                feature_prob = calculate_gaussian_probability(float(value), mean, std_dev)
                class_prob *= feature_prob
                log_line += f",{feature_prob}"
            else:  # Categorical feature
                feature_prob = 1 / (class_count + len(categorical_counts[target_class].get(j, {})))
                if value in categorical_counts[target_class].get(j, {}):
                    feature_prob = categorical_counts[target_class][j][value] / class_count
                class_prob *= feature_prob
                log_line += f",{feature_prob}"

        log_line += f"={class_prob}"  # Log final class probability
        log_data.append(log_line)

        if class_prob > best_prob:
            best_prob = class_prob
            best_class = target_class

    return best_class, log_data

def main():
    input_file = "input.csv"
    data = read_csv(input_file)

    # User provides the index of the target (class) column
    target_col = int(input("Enter the index of the target column (0-indexed): "))

    categorical_counts, numerical_stats, class_counts = train_naive_bayes(data, target_col)

    # Ask user for a new instance for prediction
    new_instance = []
    print("Enter the values for the new instance: ")
    for i in range(len(data[0])):
        if i == target_col:
            continue
        value = input(f"{data[0][i]}: ")
        new_instance.append(value)

    # Predict the class and log intermediate results
    predicted_class, log_data = predict_naive_bayes(data, target_col, categorical_counts, numerical_stats, class_counts, new_instance)

    log_data.append(f"Predicted Class: {predicted_class}")

    # Write results to output.csv
    output_file = "output.csv"
    write_csv(output_file, log_data)

    print(f"Predicted Class: {predicted_class}")
    print(f"Results and intermediate calculations written to {output_file}")

if __name__ == "__main__":
    main()
