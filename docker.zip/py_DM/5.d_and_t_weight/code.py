import csv

# Open input file and process data
input_filename = "exp4_input.csv"
output_filename = "exp4_output.csv"

classrowcolMap = {}
colMap = {}
rowMap = {}

try:
    with open(input_filename, mode='r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header row

        for line in reader:
            row, col, count = line
            val = int(count)

            # Populate classrowcolMap
            if row not in classrowcolMap:
                classrowcolMap[row] = {}
            classrowcolMap[row][col] = val

            # Update colMap and rowMap
            colMap[col] = colMap.get(col, 0) + val
            rowMap[row] = rowMap.get(row, 0) + val

    # Display values for debugging
    for r in rowMap:
        for c in colMap:
            print(f"{r}-{c}: {classrowcolMap.get(r, {}).get(c, 0)}")

    # Display row and column sums
    for r, r_sum in rowMap.items():
        print(f"{r} -> {r_sum}")
    for c, c_sum in colMap.items():
        print(f"{c} -> {c_sum}")

    # Calculate total sums
    colSum = sum(colMap.values())
    rowSum = sum(rowMap.values())
    print(f"colSum: {colSum}")
    print(f"rowSum: {rowSum}")

    # Write to output CSV
    with open(output_filename, mode='w', newline='') as fw:
        writer = csv.writer(fw)
        writer.writerow(["Column\\row", "", "Bollywood", "", "", "Tollywood", "", "", "Total", "", "", ""])
        writer.writerow(["Count", "t - weight", "d - weight", "Count", "t - weight", "d - weight", "Count", "t - weight", "d - weight"])

        # Write row data
        for r, r_sum in rowMap.items():
            row = [r]
            for c, c_sum in colMap.items():
                cell_count = classrowcolMap.get(r, {}).get(c, 0)
                t_weight = (cell_count / r_sum) * 100 if r_sum > 0 else 0
                d_weight = (cell_count / c_sum) * 100 if c_sum > 0 else 0
                row.extend([cell_count, f"{t_weight:.2f}%", f"{d_weight:.2f}%"])

            row.extend([r_sum, "100%", f"{(r_sum / colSum) * 100:.2f}%"])
            writer.writerow(row)

        # Write column totals
        total_row = ["Total"]
        for c, c_sum in colMap.items():
            total_row.extend([c_sum, f"{(c_sum / colSum) * 100:.2f}%", "100%"])
        total_row.extend([colSum, "100%", "100%"])
        writer.writerow(total_row)

    print(f"Results have been saved to {output_filename}")

except FileNotFoundError:
    print(f"Error: Could not open the file {input_filename}.")
