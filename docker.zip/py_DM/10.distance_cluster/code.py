import math
import csv

# Function to calculate distance between two points
def distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def main():
    # Reading input file
    v = []
    with open("cluster_input.csv", "r") as infile:
        reader = csv.reader(infile)
        next(reader)  # Skip the header line
        
        # Read the points from the input file
        for line in reader:
            point, x, y = line
            val1 = int(x)
            val2 = int(y)
            v.append((val1, val2))
    
    # Calculate the midpoint
    n = len(v)
    x_sum = sum(point[0] for point in v)
    y_sum = sum(point[1] for point in v)
    
    mid_x = x_sum / n
    mid_y = y_sum / n
    print(f"Mid Point: ({mid_x}, {mid_y})")
    
    # Write the output to a file
    with open("cluster_output.csv", "w", newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(["", "p1", "p2", "p3", "p4", "C"])
        
        # Write distances to the output file
        for i in range(len(v)):
            row = [f"p{i + 1}"]
            for j in range(i + 1):
                f_x1, s_y1 = v[i]
                f_x2, s_y2 = v[j]
                
                if f_x1 == f_x2 and s_y1 == s_y2:
                    row.append("0")
                    break
                dis = distance(f_x1, s_y1, f_x2, s_y2)
                row.append(f"{dis}")
            writer.writerow(row)
        
        # Calculate the nearest point to the midpoint
        nearest = float("inf")
        ans = 0
        x_new = 0
        y_new = 0
        for i in range(len(v)):
            first, second = v[i]
            dist = distance(mid_x, mid_y, first, second)
            print(f"Distance of p{i + 1} from centre: {dist}")
            if nearest > dist:
                nearest = dist
                ans = i + 1
                x_new = first
                y_new = second
            row = [f"{dist}"]
            if i == len(v) - 1:
                row.append("0")
            writer.writerow(row)
        
        print(f"Nearer Distance: {nearest}")
        print(f"Nearest point from Centre is: p{ans}")
        writer.writerow([])
        
        # New Centre calculation
        writer.writerow([",", "New Centre"])
        writer.writerow([",", "p1", "p2", "p3", "p4"])
        for i in range(len(v)):
            row = [f"p{i + 1}"]
            for j in range(i + 1):
                f_x1, s_y1 = v[i]
                f_x2, s_y2 = v[j]
                if f_x1 == f_x2 and s_y1 == s_y2:
                    row.append("0")
                    break
                dis = distance(f_x1, s_y1, f_x2, s_y2)
                row.append(f"{dis}")
            writer.writerow(row)
        
        # Write distances from the new center
        row = [f"p{ans}(New Center)"]
        for i in range(len(v)):
            first, second = v[i]
            dist = distance(x_new, y_new, first, second)
            print(f"Distance of p{i + 1} from p{ans}: {dist}")
            row.append(f"{dist}")
            if i == len(v) - 1:
                row.append("0")
        writer.writerow(row)

if __name__ == "__main__":
    main()
