import csv
import math

def min_max_normalization(data):
    min_val = min(data)
    max_val = max(data)
    return [(value - min_val) / (max_val - min_val) for value in data]

def z_score_normalization(data):
    mean = sum(data) / len(data)
    std_dev = math.sqrt(sum((value - mean) ** 2 for value in data) / len(data))
    return [(value - mean) / std_dev for value in data]

def read_csv(filename):
    data = []
    with open(filename, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            data.extend(map(float, row))  # Convert each value to float and add to data list
    return data

def write_to_file(filename, min_max_normalized, z_score_normalized):
    with open(filename, 'w') as file:
        file.write("Min-Max Normalized Data:\n")
        file.write(" ".join(map(str, min_max_normalized)))
        file.write("\n\nZ-Score Normalized Data:\n")
        file.write(" ".join(map(str, z_score_normalized)))
        file.write("\n")

def main():
    input_filename = "data.csv"  # Input CSV file name
    output_filename = "normalized_output.txt"  # Output file name

    data = read_csv(input_filename)
    
    min_max_normalized = min_max_normalization(data)
    z_score_normalized = z_score_normalization(data)

    # Write results to output file
    write_to_file(output_filename, min_max_normalized, z_score_normalized)

    print(f"Normalization results have been written to {output_filename}")

if __name__ == "__main__":
    main()
